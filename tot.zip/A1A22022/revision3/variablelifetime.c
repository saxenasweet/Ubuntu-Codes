#include<stdio.h>
void main(void)
{
int i=3;
printf("%d\n",i);
if(i==3)
{
int i=6;
printf("%d\n",i);
i++;
}
printf("%d\n",i);
}
