void main(void)
{
return_type func_name(datatype1 var1,datatype2 var2,...); 
//Declaration

data_type varname;
.
.
varname=func_name(var1,var2,...);
.
.
}
return_type func_name(datatype1 var1,datatype2 var2,...)
{
body of the function
return var_name;
}
