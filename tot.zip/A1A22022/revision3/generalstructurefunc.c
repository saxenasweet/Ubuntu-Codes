return_type name_of_function(data_type1 var_nam1,data_type2 var_nam2,..)
{
body of the function
.
.
.
.
.
return return_type;
}

int factorial(int x)
{
.
.
.
}
