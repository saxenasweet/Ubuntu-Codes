struct <name>
{
data_type varname;
data_type varname;
.
.
.
}tag_name;

e.g.
struct date
{
int dd;
int mm;
int yyyy;
}d1,d2;

