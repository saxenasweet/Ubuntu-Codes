#include<stdio.h>
void main(void)
{
printf("Hello\n");
printf("Welcome to BIT");
}

