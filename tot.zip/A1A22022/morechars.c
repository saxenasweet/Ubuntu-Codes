/*
Characters ->enclosed in single quotes
'a'
'1'
'+'
More characters
"ab"
"12"
array of characters ->string
'1' and 1 and 1.000000 are all different
char   int     float
"amit" ->valid
'amit' ->invalid
*/
