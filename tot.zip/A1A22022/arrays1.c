#include<stdio.h>
void main(void)
{
int a[4]={1,2,3,4};
int c;
c=a[0]+a[1]+a[2]+a[3];
printf("%d\n",c);
}

