#include<stdio.h>
void main(void)
{
int n;
scanf("%d",&n);
if((n>=1)&&(n<=100))
 printf("%d is between 1 and 100\n",n);
else
 printf("%d is not between 1 and 100\n",n);
}

