#include<stdio.h>
void main(void)
{
float r,a,p;
const float pi=22/7.0;
scanf("%f",&r);
a=pi*r*r;
p=pi*2*r;
printf("%f %f\n",a,p);
}
