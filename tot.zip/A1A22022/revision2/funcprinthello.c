#include<stdio.h>
void main(void)
{
void printhello(void);
printhello();
}
void printhello(void)
{
printf("Hello");
}
