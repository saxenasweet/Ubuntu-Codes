#include<stdio.h>
void main(void)
{
int i=1;
do
{
printf("%d ",i);
i++;
}while(i<=10);
}
/*
Syntax:
do
{
body of the loop
}while(condition); //The body of the loop is guaranteed to execute
//atleast once
*/

