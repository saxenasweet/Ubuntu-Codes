#include<stdio.h>
void main(void)
{
auto int a=1;
printf("%d\n",a);
}

