#include<stdio.h>
void main(void)
{
int n;
int l;
scanf("%d",&n);
for(l=1;l<=10;l++)
 printf("%dX%d=%d\n",n,l,l*n);
}
