#include<stdio.h>
void main(void)
{
int a,b,c;
a=3;
b=6;
c=a+b;
printf("%d+%d=%d",a,b,c);
}

