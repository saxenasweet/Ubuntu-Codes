#include<stdio.h>
void main(void)
{
int i=1;
for(;;)
{
 printf("%d ",i);
 i++;
 if(i==11)
  break;
}
}

