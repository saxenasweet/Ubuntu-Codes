#include<stdio.h>
void main(void)
{
int a=8;
int c;
c=a>>2; //Bit wise operators
printf("%d\n",c);
}

