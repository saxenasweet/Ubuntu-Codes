#include<stdio.h>
void main(void)
{
printf("Hello Anshul hope you are doing good\rWelcome to BIT");
}
