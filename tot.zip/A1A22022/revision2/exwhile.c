#include<stdio.h>
void main(void)
{
int i=1;
while(i<=10)
{
printf("%d ",i);
i++;
}
}
/*
Syntax:
while(condition)
{
body of the loop
}
*/
