#include<stdio.h>
void main(void)
{
printf("Hello..\nWelcome to BIT\nMy name is Kshitiz Saxena\n");
printf("**********************\n");
printf("*                    *\n");
printf("*                    *\n");
printf("**********************\n");
}
