#include<stdio.h>
void main(void)
{
int a,b,c,d,e,f,g;
a=4;
b=2;
c=a+b;
printf("%d+%d=%d\n",a,b,c);
d=a-b;
printf("\n%d",d);
e=a*b;
printf("\n%d",e);
f=a/b;
printf("\n%d",f);
g=a%b;
printf("\n%d",g);
}

