#include<stdio.h>
void main(void)
{
int i;
printf("%d\n",sizeof(i));
printf("%d\n",sizeof(float));
printf("%d\n",sizeof(char));
}
