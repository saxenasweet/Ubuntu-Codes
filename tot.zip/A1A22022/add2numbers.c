#include<stdio.h>
void main(void)
{
int a,b,c,d,e,f,g;
a=2;
b=4;
c=a+b;
printf("%d+%d=%d\n",a,b,c);
d=a-b;
printf("%d\n",d);
e=a*b;
printf("%d\n",e);
f=a/b;
printf("%d\n",f);
g=a%b;
printf("%d\n",g);
}

