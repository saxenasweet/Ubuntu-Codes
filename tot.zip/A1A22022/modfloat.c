#include<stdio.h>
void main(void)
{
float a,b,c;
a=4.2;
b=2.3;
c=a%b;
printf("%f",c);
}

