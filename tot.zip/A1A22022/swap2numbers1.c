#include<stdio.h>
void main(void)
{
int a=3;
int b=6;
int c; //Swapping 2 numbers by using a third variable
c=a; //c=3
a=b; //a=6
b=c; //b=3
printf("%d %d\n",a,b);
}
