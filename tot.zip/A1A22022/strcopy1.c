#include<stdio.h>
#include<string.h>
void main(void)
{
char st[30];
//char st[30]="amit";
char ct[30];
gets(st);
strcpy(ct,st);
puts(ct);
}
