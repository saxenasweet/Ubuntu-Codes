#include<stdio.h>
void main(void)
{
int i=1;
while(i>0)
{
i++;
}
printf("Minimum is %d and Maximum is %d\n",i,i-1);
}

