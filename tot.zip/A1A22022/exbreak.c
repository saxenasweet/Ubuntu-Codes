#include<stdio.h>
void main(void)
{
int i=1;
do
{
if(i==3)
 continue;
printf("%d ",i);
i++;
}while(i<=10);
}

