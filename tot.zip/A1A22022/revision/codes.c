ASCII CODES
American Standard Code for Information Interchange 
It is a 7 bit code
'A'  ->65
'a' ->97
'0' ->48
' ' ->32

X X X X X X X
0 0 0 0 0 0 0  ->0 (base 10)
1 1 1 1 1 1 1  ->127 (base 10)
Using  a 7 bit code I ca represent 128 characters
Add 1 bit to ASCII -> EBCDIC  8 bit code and is used to represent 256 characters
UNICODE -> Universal Code ->4 byte 
