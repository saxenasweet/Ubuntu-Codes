#include<stdio.h>
void main(void)
{
int i;
if(i=0)
 printf("One");
else
 printf("Some thing else");
}

