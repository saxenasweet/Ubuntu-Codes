a
bc
def
ghij
klmno

Here the user will enter the number of rows

a
ab
abc
abcd
abcde

Here the user will enter the number of rows
