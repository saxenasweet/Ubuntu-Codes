#include<stdio.h>
void main(void)
{
int a[10]; //integer array of 10 numbers
float b[10]; //floating point array of 10 numbers
char c[10]; //Character array of 10 characters -> String
a[0] ->First integer
b[2] -> Third floating point number
c[4] -> Fifth character
}


