#include<stdio.h>
void main(void)
{
int a=4,b=3,c;
//c=a>b?a:b;
if(a>b)
  c=a;
else
  c=b;
printf("%d\n",c);
}

