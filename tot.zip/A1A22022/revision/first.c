/*
Hello
Welcome to the world of computing
Have a Good Day
*/
#include<stdio.h>
//C is case sensitive
void main(void)
{
printf("Hello\b"); //Escape Sequence
printf("Welcome to the world of computing\b");
printf("Have a Good Day\n\a");
}
/*
\n New Line
\t 4 or 8 blank spaces
\b backspace
\a Alert (beep sound)
*/
