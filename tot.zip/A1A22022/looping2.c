#include<stdio.h>
void main(void)
{
int i=1;
int n;
scanf("%d",&n);
while(i<=10)
{
printf("%d\n",i*n);
i=i+1;
}
}

