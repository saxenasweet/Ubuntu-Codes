#include<stdio.h>
void main(void)
{
int i;
for(i=1;i<=10;i=i+2)
{
printf("%d ",i);
}
}

