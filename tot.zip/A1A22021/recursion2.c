#include<stdio.h>
void main(void)
{
void print(void);
print();
}
void print(void)
{
printf("Hello");
print(); //Calling the function
}

