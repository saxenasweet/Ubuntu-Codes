/*
File is a collection of records.
Record is a collection of field values.
Field is a data type value.
e.g.
Name	Roll_No		PCMPER
AMIT	1		98.4    <- RECORD
DEEPAK	2		78.6
RAVI	3		88.2

FIELDS -> Name, Roll_No and PCMPER
Files are of two types -> In machine level form, binary form -> EXECUTABLE FILES
Human Understandable Format -> TEXT FILES

Every file has a name->FILE NAME-> PRIMARY NAME & SECONDARY (EXTENSION) NAME
e.g. CLASS3A.TXT -> TXT->SECONDARY NAME CLASS3A -> PRIMARY NAME
FILES CAN BE ACCESSED IN 2 WAYS->
1. SEQUENTIAL ACCESS
2. RANDOM ACCESS
*/

