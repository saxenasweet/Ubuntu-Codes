#include<stdio.h>
void main(void)
{
int age;
printf("Enter your age?");
scanf("%d",&age);
if(age>=18)
 printf("You can vote!");
else
 printf("You wait to vote!");
}

