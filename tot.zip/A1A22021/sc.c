int a=6;

