#include<stdio.h>
void main(void)
{
typedef int INTEGER; //typedef is a keyword to define our own data type
typedef char C;
INTEGER a=2,b=3,c=4;
printf("%d %d %d\n",a,b,c);
}
