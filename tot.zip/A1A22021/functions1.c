/*
Two types:
Library Functions ->printf , scanf , pow , log , exp , strlen , strcmp
User Defined Functions ->a coder defines

A set of statements which take some input and returns an output
*/
#include<stdio.h>
void main(void)
{
int a;
int b,c,d;
a=printf("hello");
printf("\n%d",a);
d=scanf("%d %d",&b,&c);
printf("\n%d",d);
}


