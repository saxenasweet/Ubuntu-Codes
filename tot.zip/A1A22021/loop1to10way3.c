#include<stdio.h>
void main(void)
{
float i=-9;
while(i<=-1)
{
printf("%f ",i);
i=i+.5;
}
}

