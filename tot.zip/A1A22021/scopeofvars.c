#include<stdio.h>
void main(void)
{
int a=3;
printf("%d",a);
//float a=6.2;
if(a==3)
{
float a=6.2;
a++;
printf("\n%f\n",a);
}
a++;
printf("%d\n",a);
}

