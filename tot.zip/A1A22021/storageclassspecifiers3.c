int a=6;
