#include<stdio.h>
void main(void)
{
int i=1;
for(;;)
{
printf("%d\n",i);
i=i+1;
if(i>10)
 break;
}
}

