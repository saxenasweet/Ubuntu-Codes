#include<stdio.h>
void main(void)
{
#define PII 3.14 //Preprocessor Directive
const float PI=3.14;
//PI++;
printf("%f\n",PI);
printf("%f\n",PII);
}
