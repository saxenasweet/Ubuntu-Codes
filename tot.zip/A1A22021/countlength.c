#include<stdio.h>
void main(void)
{
char ch;
scanf("%c",&ch);
if((ch=='a')||(ch=='e')||(ch=='i')||(ch=='o')||(ch=='u')||(ch=='A')||(ch=='E')||(ch=='I')||(ch=='O')||(ch=='U'))
 printf("You entered a vowel\n");
else
 printf("You entered a consonant\n");
}

