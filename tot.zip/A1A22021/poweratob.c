#include<stdio.h>
#include<math.h>
void main(void)
{
float a;
float b;
float c;
scanf("%f %f",&a,&b);
c=pow(a,b);
printf("%f\n",c);
}

