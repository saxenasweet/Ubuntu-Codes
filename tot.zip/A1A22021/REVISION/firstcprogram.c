#include<stdio.h>
void main(void)
{
printf("Hello");
}
/*What are the steps in EXECUTING a C Program?
1. Write the C Program ?
EDITOR e.g. nano -> LINUX , NOTEPAD ->WINDOWS , NOTEPAD++ ->WINDOWS (APPLICATION SOFTWARE)
IDE ->INTEGRATED DEVELOPMENT ENVIRONMENT e.g. VISUAL STUDIO -> MICROSOFT , CODEBLOCK , 
TURBOC ->BORLAND : write the code, compile it , help
2. Compile? COMPILER -> SYSTEM SOFTWARE
Using a compiler gcc , tcc.exe
a. PREPROCESSOR
b. OBJECT FILE  ->Your code is converted to machine understandable form
c. LINKING ->all external references in a code are resolved ->LINKER (SYSTEM SOFTWARE)
c. EXECUTABLE FILE a.out / a.exe ->STANDALONE -> you can execute the file without
using the compiler 
*/
