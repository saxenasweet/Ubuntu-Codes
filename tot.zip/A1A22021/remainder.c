#include<stdio.h>
void main(void)
{
int a;
int c;
int b;
scanf("%d %d",&a,&b);
c=a%b; //% is called modulous operator
if(c==0)
 printf("%d divides %d\n",b,a);
else
 printf("%d does not divie %d\n",b,a);
}
//Write a code to enter two numbers a and b .
//check if b divides a
/*
Code written on
8 Nov 2021
at
2:32 PM
*/

