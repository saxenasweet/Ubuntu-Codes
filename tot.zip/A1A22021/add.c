#include<stdio.h>
void main(void)
{
int i,j,k;
scanf("%d",&i);
scanf("%d",&j);
k=i%j;
printf("%d %% %d=%d",i,j,k);
}

