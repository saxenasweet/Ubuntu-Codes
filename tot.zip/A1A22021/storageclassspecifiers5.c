#include<stdio.h>
void main(void)
{
register int a=5; //for performance benefit
printf("%d",a);
}

