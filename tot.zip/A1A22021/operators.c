#include<stdio.h>
void main(void)
{
int n=1;
//n+=1;//n=n+1
//n=n*2//n*=2
//+ * / _ % Binary Arithmatic Operators
//printf("%d",n);
//n++  -> post increment  ++n -> pre increment n=n+1
printf("%d\n",++n);
printf("\n%d",n);
}

